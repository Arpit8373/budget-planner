A web application which allows the user to plan a budget based on a regular income. It divides planned expenditure into two categories, 'free' and 'fixed'. The user can add and remove subcategories as they chose. They can also select the frequency of their income, and see how much they are projected to save.

This is my first attempt at a project using HTML/CSS/JavaScript. I use the jQuery library and the Bootstrap framework.
